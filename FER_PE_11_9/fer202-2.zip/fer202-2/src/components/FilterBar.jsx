import React from 'react';
import { Card, Form, Row, Col } from 'react-bootstrap';
import { useExpense } from '../contexts/ExpenseContext';

const FilterBar = () => {
    const { filters, sortBy, setFilter, setSort, getUniqueSemesters, getUniqueCourses } = useExpense();
    
    const handleSearchChange = (e) => {
        setFilter('search', e.target.value);
    };

    const handleSemesterChange = (e) => {
        setFilter('category', e.target.value);
    };

    const handleCourseChange = (e) => {
        setFilter('course', e.target.value);
    };

    const handleSortChange = (e) => {
        setSort(e.target.value);
    };

    const categorys = getUniqueSemesters();
    const courses = getUniqueCourses();
    
    return (
        <Card className="mb-4 shadow-sm">
            <Card.Header as="h5">Filter</Card.Header>
            <Card.Body>
                <Form>
                    <Row className="g-3">
                        
                        
                        {/* Filter by Semester  */}
                        <Col xs={6} md={4} lg={2}>
                            <Form.Group>
                                <Form.Label>Category</Form.Label>
                                <Form.Select value={filters.category} onChange={handleSemesterChange}>
                                    <option value="">All Category</option>
                                    {categorys.map(category => (
                                        <option key={category} value={category}>{category}</option>
                                    ))}
                                </Form.Select>
                            </Form.Group>
                        </Col>
                        
                    
                    </Row>
                </Form>
            </Card.Body>
        </Card>
    );
};

export default FilterBar;