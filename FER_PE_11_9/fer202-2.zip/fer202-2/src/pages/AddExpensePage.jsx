import React from 'react';
import AddExpenseForm from '../components/AddExpenseForm';

const AddExpensePage = () => {
    return <AddExpenseForm />;
};

export default AddExpensePage;
